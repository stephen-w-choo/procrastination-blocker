var n=(r=>(r.productive="productive",r.procrastination="procrastination",r))(n||{}),t=(r=>(r.notSeen="notSeen",r))(t||{});export{n as C,t as S};
